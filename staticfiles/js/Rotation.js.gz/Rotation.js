function charger()
{

    setTimeout(function(){
        document.getElementById("everything").style.display="block";
        document.getElementById("loader").style.display="none";
    }, 3000);//

}